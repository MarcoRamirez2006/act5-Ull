package com.example.act5ull0531

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
