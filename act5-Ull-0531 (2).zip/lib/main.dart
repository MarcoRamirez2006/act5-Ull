import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'Material App',
        home: Scaffold(
            appBar: AppBar(
              title: const Text('Marc Cars'),
            ), //AppBar
            body: const ShowSheet()));
  }
}

class ShowSheet extends StatelessWidget {
  const ShowSheet({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        ListTile(
          leading: const Icon(
            Icons.school_outlined,
            size: 40.0,
            color: Color(0xffff9800),
          ),
          title: const Text("Mas informacion"),
          subtitle: const Text('Tap para ver mas'),
          trailing: const Icon(Icons.arrow_forward_ios),
          onTap: () {
            _mySheet(context);
          },
        )
      ],
    );
  }

  _mySheet(BuildContext context) {
    List myList = List.generate(50, (i) => i);

    showModalBottomSheet(
      barrierColor: Colors.black54,
      backgroundColor: Colors.blue,
      isDismissible: true,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
      context: context,
      builder: (context) {
        return SizedBox(
          height: 500.0,
          child: ListView.builder(
            itemCount: myList.length,
            itemBuilder: (_, i) => ListTile(
              title: Text(myList[i].toString()),
            ),
          ),
        );
      },
    );
  }
}
